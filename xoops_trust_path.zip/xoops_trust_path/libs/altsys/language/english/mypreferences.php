<?php

define( '_MD_A_MYPREFERENCES_FORMTITLE' , 'Module\'s preferences' ) ;
define( '_MD_A_MYPREFERENCES_UPDATED' , 'Preferences are updated successfully' ) ;

?>