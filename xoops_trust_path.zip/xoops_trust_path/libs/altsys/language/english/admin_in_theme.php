<?php

define( '_MD_A_AINTHEME_FMT_PUBLICTOP' , 'Public Top of %s' ) ;
define( '_MD_A_AINTHEME_FMT_ADMINTOP' , 'Admin Top of %s' ) ;


?>