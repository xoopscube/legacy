<?php

define( '_MD_A_MYTPLSFORM_TPLSADMIN' , 'Templates' ) ;
define( '_MD_A_MYTPLSFORM_EDIT' , 'Editing the template' ) ;
define( '_MD_A_MYTPLSFORM_UPDATED' , 'The template is updated successfully' ) ;
define( '_MD_A_MYTPLSFORM_CREATED' , 'A template is created successfully' ) ;
define( '_MD_A_MYTPLSFORM_LABEL_TPLFILE' , 'Template name' ) ;
define( '_MD_A_MYTPLSFORM_BTN_MODIFYCONT' , 'Reflect' ) ;
define( '_MD_A_MYTPLSFORM_BTN_MODIFYEND' , 'Save and Finish' ) ;
define( '_MD_A_MYTPLSFORM_BTN_CREATE' , 'Create' ) ;
define( '_MD_A_MYTPLSFORM_BTN_RESET' , 'Reset' ) ;

?>