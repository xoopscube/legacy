<?php

define( '_MYLANGADMIN_H3_MODULE' , 'Target module' ) ;
define( '_MYLANGADMIN_CACHEUPDATED' , 'The cache file has been updated' ) ;
define( '_MYLANGADMIN_BTN_UPDATE' , 'Update' ) ;
define( '_MYLANGADMIN_BTN_RESET' , 'Reset' ) ;

define( '_MYLANGADMIN_TH_CONSTANTNAME' , 'Constant Name' ) ;
define( '_MYLANGADMIN_TH_DEFAULTVALUE' , 'Default Value' ) ;
define( '_MYLANGADMIN_TH_USERVALUE' , 'User Value' ) ;

define( '_MYLANGADMIN_NOTE_ADDEDBYMYLANG' , '(a constant added by user)' ) ;
define( '_MYLANGADMIN_DT_MYLANGFILENAME' , 'Partially overriding file name' ) ;

define( '_MYLANGADMIN_DT_CACHEFILENAME' , 'Cache file name' ) ;
define( '_MYLANGADMIN_DT_CACHESTATUS' , 'Caching status' ) ;
define( '_MYLANGADMIN_CREATED' , 'Created' ) ;
define( '_MYLANGADMIN_NOTCREATED' , 'Has not created yet' ) ;

define( '_MYLANGADMIN_ERR_MODNOLANGUAGE' , 'Selected module does not have language folder' ) ;
define( '_MYLANGADMIN_ERR_MODLANGINCOMPATIBLE' , 'Selected module has incompatible language structure' ) ;
define( '_MYLANGADMIN_ERR_MODEMPTYLANGDIR' , 'Selected module does not have overridable language file' ) ;

define( '_MYLANGADMIN_MSG_D3LANGMANENABLED' , 'The overriding system is enabled now.' ) ;
define( '_MYLANGADMIN_FMT_HOWTOENABLED3LANGMAN4XCL' , 'The overriding system is disabled now. To enable it, copy "%s" into "%s"' ) ;
define( '_MYLANGADMIN_MSG_HOWTOENABLED3LANGMAN4X2' , 'The overriding system cannot work with this XOOPS core except some D3 modules. If you want to enable it with this core, try to hack like this:' ) ;
define( '_MYLANGADMIN_MSG_NOTICE4ALREADYREAD' , 'Since this file has been already read by system, this column means current value' ) ;

?>