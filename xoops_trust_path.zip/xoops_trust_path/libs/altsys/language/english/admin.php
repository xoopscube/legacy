<?php

define( '_MD_A_DBUPDATED' , 'Database updated successfully' ) ;


?>