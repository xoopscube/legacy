<?php

define( '_MYLANGADMIN_H3_MODULE' , '言語定数操作対象モジュール' ) ;
define( '_MYLANGADMIN_CACHEUPDATED' , '言語キャッシュを更新しました' ) ;
define( '_MYLANGADMIN_BTN_UPDATE' , '更新' ) ;
define( '_MYLANGADMIN_BTN_RESET' , 'リセット' ) ;

define( '_MYLANGADMIN_TH_CONSTANTNAME' , '定数名' ) ;
define( '_MYLANGADMIN_TH_DEFAULTVALUE' , 'デフォルト値' ) ;
define( '_MYLANGADMIN_TH_USERVALUE' , '上書き設定値' ) ;

define( '_MYLANGADMIN_NOTE_ADDEDBYMYLANG' , '(※独自に追加された定数)' ) ;
define( '_MYLANGADMIN_DT_MYLANGFILENAME' , '差分オーバーライドファイル名' ) ;

define( '_MYLANGADMIN_DT_CACHEFILENAME' , 'キャッシュファイル名' ) ;
define( '_MYLANGADMIN_DT_CACHESTATUS' , 'キャッシュ状況' ) ;
define( '_MYLANGADMIN_CREATED' , '作成済' ) ;
define( '_MYLANGADMIN_NOTCREATED' , '未作成' ) ;

define( '_MYLANGADMIN_ERR_MODNOLANGUAGE' , '言語ファイルを持たないモジュールです' ) ;
define( '_MYLANGADMIN_ERR_MODLANGINCOMPATIBLE' , '言語ファイルディレクトリ構造に互換性のないモジュールです' ) ;
define( '_MYLANGADMIN_ERR_MODEMPTYLANGDIR' , 'このモジュールは変更可能な言語ファイルを持っていません' ) ;

define( '_MYLANGADMIN_MSG_D3LANGMANENABLED' , '言語ファイルオーバーライドシステムは有効になっています' ) ;
define( '_MYLANGADMIN_FMT_HOWTOENABLED3LANGMAN4XCL' , '言語ファイルオーバーライドシステムは無効になっています。有効にするには、"%s" を "%s" にコピーしてください' ) ;
define( '_MYLANGADMIN_MSG_HOWTOENABLED3LANGMAN4X2' , 'このコアでは、言語ファイルオーバーライドシステムはD3LanguageManager対応モジュールでしか有効になりません。非対応モジュールでもオーバーライドシステムを利用する場合は、以下のHackを試してください。' ) ;
define( '_MYLANGADMIN_MSG_NOTICE4ALREADYREAD' , '現在編集中のファイルはすでにシステムで読み込み済のため、このカラムはデフォルトではなく現在値を示しています' ) ;

?>