<?php

define( '_MD_A_MYPREFERENCES_FORMTITLE' , 'モジュール一般設定' ) ;
define( '_MD_A_MYPREFERENCES_UPDATED' , '一般設定を更新しました' ) ;

?>