<?php

define( '_MD_A_DBUPDATED' , 'データベースを更新しました' ) ;


?>