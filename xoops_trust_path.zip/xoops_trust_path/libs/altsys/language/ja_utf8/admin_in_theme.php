<?php

define( '_MD_A_AINTHEME_FMT_PUBLICTOP' , '%s公開トップ' ) ;
define( '_MD_A_AINTHEME_FMT_ADMINTOP' , '%s管理トップ' ) ;


?>