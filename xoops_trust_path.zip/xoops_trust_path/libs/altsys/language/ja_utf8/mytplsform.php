<?php

define( '_MD_A_MYTPLSFORM_TPLSADMIN' , 'テンプレート管理' ) ;
define( '_MD_A_MYTPLSFORM_EDIT' , 'テンプレート編集' ) ;
define( '_MD_A_MYTPLSFORM_UPDATED' , 'テンプレートを更新しました' ) ;
define( '_MD_A_MYTPLSFORM_CREATED' , 'テンプレートを作成しました' ) ;
define( '_MD_A_MYTPLSFORM_LABEL_TPLFILE' , 'テンプレート名' ) ;
define( '_MD_A_MYTPLSFORM_BTN_MODIFYCONT' , '更新して編集継続' ) ;
define( '_MD_A_MYTPLSFORM_BTN_MODIFYEND' , '更新して編集終了' ) ;
define( '_MD_A_MYTPLSFORM_BTN_CREATE' , '新規登録' ) ;
define( '_MD_A_MYTPLSFORM_BTN_RESET' , 'リセット' ) ;

?>