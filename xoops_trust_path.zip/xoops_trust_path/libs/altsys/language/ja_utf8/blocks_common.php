<?php

// definitions for editing blocks
define("_MB_ALTSYS_OPENCLOSE","開く/閉じる");
define("_MB_ALTSYS_THISTEMPLATE","このブロックのテンプレート");

?>