<?php

define( '_MYLANGADMIN_H3_MODULE' , 'M�d�lo que se est� modificando' ) ;
define( '_MYLANGADMIN_CACHEUPDATED' , 'El archivo de cache ha sido actualizado' ) ;
define( '_MYLANGADMIN_BTN_UPDATE' , 'Actualizar' ) ;
define( '_MYLANGADMIN_BTN_RESET' , 'Restablecer' ) ;

define( '_MYLANGADMIN_TH_CONSTANTNAME' , 'Nombre de la constante' ) ;
define( '_MYLANGADMIN_TH_DEFAULTVALUE' , 'Valor predeterminado' ) ;
define( '_MYLANGADMIN_TH_USERVALUE' , 'Valor dado por el usuario' ) ;

define( '_MYLANGADMIN_NOTE_ADDEDBYMYLANG' , '(una constante a�adida por el usuario)' ) ;
define( '_MYLANGADMIN_DT_MYLANGFILENAME' , '"Overriding" parcialmente el nombre del archivo' ) ;

define( '_MYLANGADMIN_DT_CACHEFILENAME' , 'Nombre del archivo de cache' ) ;
define( '_MYLANGADMIN_DT_CACHESTATUS' , 'Estado de la cache' ) ;
define( '_MYLANGADMIN_CREATED' , 'Creado' ) ;
define( '_MYLANGADMIN_NOTCREATED' , 'No ha sido creada a�n' ) ;

define( '_MYLANGADMIN_ERR_MODNOLANGUAGE' , 'El m�dulo seleccionado no tiene carpeta de lenguaje' ) ;
define( '_MYLANGADMIN_ERR_MODLANGINCOMPATIBLE' , 'El m�dulo seleccionado tiene una estructura de lenguaje incompatible' ) ;
define( '_MYLANGADMIN_ERR_MODEMPTYLANGDIR' , 'El m�dulo seleccionado no tiene un archivo de lenguaje de preferente selecci�n al predeterminado (override)' ) ;

define( '_MYLANGADMIN_MSG_D3LANGMANENABLED' , 'El sistema de �rdenes preferentes (overriding system) est� activado ahora.' ) ;
define( '_MYLANGADMIN_FMT_HOWTOENABLED3LANGMAN4XCL' , 'El sistema de �rdenes preferentes (overriding system) est� desactivado ahora. para activarlo, copie "%s" en "%s"' ) ;
define( '_MYLANGADMIN_MSG_HOWTOENABLED3LANGMAN4X2' , 'El sistema de �rdenes preferentes (overriding system) no puede funcionar con este n�cleo de ImpressCMS excepto con relaci�n a algunos m�dulos D3. Si desea activarlo con este n�cleo, intente hacer este "hack":' ) ;
define( '_MYLANGADMIN_MSG_NOTICE4ALREADYREAD' , 'El archivo ha sido le�do por el sistema, por lo que esta columna muestra el valor actual.' ) ;

?>