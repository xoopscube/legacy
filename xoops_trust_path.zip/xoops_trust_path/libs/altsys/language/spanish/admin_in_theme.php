<?php

define( '_MD_A_AINTHEME_FMT_PUBLICTOP' , 'P�blico (Top) de %s' ) ;
define( '_MD_A_AINTHEME_FMT_ADMINTOP' , 'Administraci�n (Top) de %s' ) ;


?>