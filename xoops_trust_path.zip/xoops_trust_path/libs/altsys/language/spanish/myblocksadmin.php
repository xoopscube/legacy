<?php


// Appended by Xoops Language Checker -GIJOE- in 2008-12-13 18:32:09
define('_MD_A_MYBLOCKSADMIN_NOTICE4COMMONFCK','If you want to use WYSIWYG editor, install common/fckeditor');

define( '_MD_A_MYBLOCKSADMIN_PERMUPDATED' , 'Los permisos se actualizaron con �xito' ) ;
define( '_MD_A_MYBLOCKSADMIN_BLOCKADMIN' , 'Administraci�n de Bloques' ) ;
define( '_MD_A_MYBLOCKSADMIN_NAME' , 'Nombre' ) ;
define( '_MD_A_MYBLOCKSADMIN_TITLE' , 'T�tulo' ) ;
define( '_MD_A_MYBLOCKSADMIN_SIDE' , 'Tipo de bloque' ) ;
define( '_MD_A_MYBLOCKSADMIN_SBLEFT' , 'o --- - izquierdo' ) ;
define( '_MD_A_MYBLOCKSADMIN_SBRIGHT' , '- --- o derecho' ) ;
define( '_MD_A_MYBLOCKSADMIN_CBLEFT' , '- o-- - central-izquierdo' ) ;
define( '_MD_A_MYBLOCKSADMIN_CBRIGHT' , '- --o - central-derecho' ) ;
define( '_MD_A_MYBLOCKSADMIN_CBCENTER' , '- -o- - central' ) ;
define( '_MD_A_MYBLOCKSADMIN_VISIBLE' , 'Visible' ) ;
define( '_MD_A_MYBLOCKSADMIN_WEIGHT' , 'Ubicaci�n' ) ;
define( '_MD_A_MYBLOCKSADMIN_VISIBLEIN' , 'Visible en' ) ;
define( '_MD_A_MYBLOCKSADMIN_CONTENT' , 'Contenido' ) ;
define( '_MD_A_MYBLOCKSADMIN_CAPT_USABLETAGS' , 'Etiquetas admitidas' ) ;
define( '_MD_A_MYBLOCKSADMIN_FMT_TAGRULE' , '%s ser� reemplazada en %s en esta vista' ) ;
define( '_MD_A_MYBLOCKSADMIN_CTYPE' , 'Tipo de contenido' ) ;
define( '_MD_A_MYBLOCKSADMIN_EDITTPL' , 'Modificar la plantilla' ) ;
define( '_MD_A_MYBLOCKSADMIN_OPTIONS' , 'Opciones de los Bloques' ) ;
define( '_MD_A_MYBLOCKSADMIN_BCACHETIME' , 'Cache' ) ;
define( '_MD_A_MYBLOCKSADMIN_ACTION' , 'Acci�n' ) ;
define( '_MD_A_MYBLOCKSADMIN_DESCRIPTION' , 'Descripci�n' ) ;
define( '_MD_A_MYBLOCKSADMIN_TOPPAGE' , 'P�gina de inicio' ) ;
define( '_MD_A_MYBLOCKSADMIN_ALLPAGES' , 'En todas' ) ;
define( '_MD_A_MYBLOCKSADMIN_PERMFORM' , 'Permisos' ) ;
define( '_MD_A_MYBLOCKSADMIN_PERM_MADMIN' , 'permiso de administraci�n del m�dulo' ) ;
define( '_MD_A_MYBLOCKSADMIN_PERM_MREAD' , 'permiso de lectura del m�dulo' ) ;
define( '_MD_A_MYBLOCKSADMIN_DBUPDATED' , 'La base de datos se actualiz� con �xito' ) ;
define( '_MD_A_MYBLOCKSADMIN_FMT_REMOVEBLOCK' , '%s ser� eliminado. �Est� seguro?' ) ;


define( '_MD_A_MYBLOCKSADMIN_CLONEFORM' , 'Duplicar el bloque' ) ;
define( '_MD_A_MYBLOCKSADMIN_NEWFORM' , 'Crear un bloque' ) ;
define( '_MD_A_MYBLOCKSADMIN_EDITFORM' , 'Modificar el bloque' ) ;

define( '_MD_A_MYBLOCKSADMIN_LINK_FORCECLONE' , 'Forzar la duplicaci�n' ) ;

define( '_MD_A_MYBLOCKSADMIN_BTN_CLONE' , 'Duplicar' ) ;
define( '_MD_A_MYBLOCKSADMIN_BTN_NEW' , 'Crear' ) ;
define( '_MD_A_MYBLOCKSADMIN_BTN_EDIT' , 'Actualizar' ) ;

define( '_MD_A_MYBLOCKSADMIN_CTYPE_HTML' , '(HTML)' ) ;
define( '_MD_A_MYBLOCKSADMIN_CTYPE_NOSMILE' , '(HTML+BBCODE+AutoLink)' ) ;
define( '_MD_A_MYBLOCKSADMIN_CTYPE_SMILE' , '(HTML+BBCODE+AutoLink+Smiley)' ) ;
define( '_MD_A_MYBLOCKSADMIN_CTYPE_PHP' , '(PHP eval())' ) ;


// Group permission phrases
define('_MD_A_MYBLOCKSADMIN_PERMADDNG', 'No fue posible a�adir %s permisos a %s para el grupo %s');
define('_MD_A_MYBLOCKSADMIN_PERMADDOK','A�adidos %s permisos para %s para el grupo %s');
define('_MD_A_MYBLOCKSADMIN_PERMRESETNG','No es posible restablecer los permisos de grupo para el m�dulo %s');
define('_MD_A_MYBLOCKSADMIN_PERMADDNGP', 'Todos los items superiores (parents) deben ser seleccionados.');


?>
