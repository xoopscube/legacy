<?php

define( '_MD_A_DBUPDATED' , 'La base de datos se actualiz� con �xito' ) ;


?>