<?php

// definitions for editing blocks
define("_MB_ALTSYS_OPENCLOSE","Abrir/Cerrar");
define("_MB_ALTSYS_THISTEMPLATE","Plantilla de este bloque");

?>