<?php


// Appended by Xoops Language Checker -GIJOE- in 2008-07-09 13:28:58
define('_MD_A_MYTPLSFORM_TPLSADMIN','Templates');

define( '_MD_A_MYTPLSFORM_EDIT' , 'Modificar la plantilla' ) ;
define( '_MD_A_MYTPLSFORM_UPDATED' , 'La plantilla fue actualizada con �xito' ) ;
define( '_MD_A_MYTPLSFORM_CREATED' , 'La plantilla fue creada con �xito' ) ;
define( '_MD_A_MYTPLSFORM_LABEL_TPLFILE' , 'Nombre de la plantilla' ) ;
define( '_MD_A_MYTPLSFORM_BTN_MODIFYCONT' , 'Guardar cambios' ) ;
define( '_MD_A_MYTPLSFORM_BTN_MODIFYEND' , 'Guardar cambios y finalizar' ) ;
define( '_MD_A_MYTPLSFORM_BTN_CREATE' , 'Crear' ) ;
define( '_MD_A_MYTPLSFORM_BTN_RESET' , 'Reestablecer' ) ;

?>