<?php

define( '_MD_A_MYPREFERENCES_FORMTITLE' , 'Preferencias del m�dulo' ) ;
define( '_MD_A_MYPREFERENCES_UPDATED' , 'Las preferencias fueron actualizadas con �xito' ) ;

?>