<?php

define( '_MYTPLSADMIN_CREATE_NEW_TPLSET' , 'Crear un nuevo conjunto' ) ;
define( '_MYTPLSADMIN_CAPTION_BASE' , 'Base' ) ;
define( '_MYTPLSADMIN_CAPTION_SETNAME' , 'Nombre' ) ;
define( '_MYTPLSADMIN_OPT_BLANKSET' , '(sin base)' ) ;
define( '_MYTPLSADMIN_CAPTION_COPYTO' , 'a' ) ;
define( '_MYTPLSADMIN_BTN_COPY' , 'Copiar' ) ;
define( '_MYTPLSADMIN_TITLE_CHECKALL' , 'Seleccionar/No seleccionar todas las plantillas de esta columna' ) ;
define( '_MYTPLSADMIN_CNF_DELETE_SELECTED_TEMPLATES' , 'Todas las plantillas seleccionadas en el conjunto (relacionadas en la columna) ser�n eliminadas. �Est� seguro?' ) ;
define( '_MYTPLSADMIN_CNF_COPY_SELECTED_TEMPLATES' , 'Todas las plantillas seleccionadas (relacionadas en la columna) ser�n copiadas/sobreescritas en el conjunto seleccionado. �Est� seguro?' ) ;
define( '_MYTPLSADMIN_TH_NAME' , 'Nombre' ) ;
define( '_MYTPLSADMIN_TH_TYPE' , 'Tipo' ) ;
define( '_MYTPLSADMIN_TH_FILE' , 'Archivo base' ) ;
define( '_MYTPLSADMIN_ERR_NOTPLFILE' , "Ninguna plantilla es comprobada." ) ;
define( '_MYTPLSADMIN_ERR_INVALIDTPLSET' , "El conjunto o juego de plantillas de destino es el mismo que el de la fuente o bien no se ha especificado un 'tplset' v�lido." ) ;
define( '_MYTPLSADMIN_ERR_CANTREMOVEDEFAULT' , "No puede eliminar el conjunto de plantillas 'default'." ) ;
define( '_MYTPLSADMIN_ERR_DUPLICATEDSETNAME' , "El nombre para el conjunto de plantillas ya existe." ) ;
define( '_MYTPLSADMIN_ERR_INVALIDSETNAME' , "Se ha especificado un nombre incorrecto para el conjunto de plantillas." ) ;

define( '_MYTPLSADMIN_H3_MODULE' , 'M�dulo' ) ;
define( '_MYTPLSADMIN_BTN_NEWTPLSET' , 'Crear' ) ;

define( '_MYTPLSADMIN_DBUPDATED' , 'Las plantillas se actualizaron con �xito' ) ;

define( '_MYTPLSADMIN_CUSTOMTEMPLATE' , 'Plantilla personalizada' ) ;
define( '_MYTPLSADMIN_CREATENEWCUSTOMTEMPLATE' , 'Crear una nueva plantilla personalizada' ) ;

?>