<?php
// $Id: mypreferences.php 1040 2011-11-06 05:24:00Z mikhail $
// License http://creativecommons.org/licenses/by/2.5/br/
define("_MD_A_MYPREFERENCES_FORMTITLE","Preferências do módulo");
define("_MD_A_MYPREFERENCES_UPDATED","As preferências foram atualizadas corretamente.");
?>