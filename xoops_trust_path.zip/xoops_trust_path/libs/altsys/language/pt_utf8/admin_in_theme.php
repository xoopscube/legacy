<?php
// $Id: admin_in_theme.php 1040 2011-11-06 05:24:00Z mikhail $
// License http://creativecommons.org/licenses/by/2.5/br/
define("_MD_A_AINTHEME_FMT_PUBLICTOP","Top público de %s");
define("_MD_A_AINTHEME_FMT_ADMINTOP","Top administrativo de %s");
?>