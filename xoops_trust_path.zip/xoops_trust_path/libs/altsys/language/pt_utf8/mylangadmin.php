<?php
// $Id: mylangadmin.php 1040 2011-11-06 05:24:00Z mikhail $
// License http://creativecommons.org/licenses/by/2.5/br/
define("_MYLANGADMIN_BTN_RESET","Redefinir");
define("_MYLANGADMIN_BTN_UPDATE","Atualizar");
define("_MYLANGADMIN_CACHEUPDATED","O arquivo cache foi atualizado");
define("_MYLANGADMIN_CREATED","Criado");
define("_MYLANGADMIN_DT_CACHEFILENAME","Nome do arquivo cache");
define("_MYLANGADMIN_DT_CACHESTATUS","Situação do cache");
define("_MYLANGADMIN_DT_MYLANGFILENAME","Nome do arquivo parcialmente alterado");
define("_MYLANGADMIN_ERR_MODEMPTYLANGDIR","O módulo selecionado não tem arquivo de idioma com permissão de leitura");
define("_MYLANGADMIN_ERR_MODLANGINCOMPATIBLE","O módulo selecionado tem estrutura de idioma incompatível");
define("_MYLANGADMIN_ERR_MODNOLANGUAGE","O módulo selecionado não tem pasta de idioma");
define("_MYLANGADMIN_FMT_HOWTOENABLED3LANGMAN4XCL","O sistema de substituição está desabilitado agora. Para habilitá-lo, copie <q>%s</q> em <q>%s</q>");
define("_MYLANGADMIN_H3_MODULE","Módulo alvo");
define("_MYLANGADMIN_MSG_D3LANGMANENABLED","O sistema de substituição está habilitado agora.");
define("_MYLANGADMIN_MSG_HOWTOENABLED3LANGMAN4X2","O sistema de substituição não está funcionando com o núcleo desta versão do XOOPS Cube, exceto alguns módulos D3. Se você deseja habilitá-lo neste core, tente um hack como este:");
define("_MYLANGADMIN_MSG_NOTICE4ALREADYREAD","Desde que este arquivo já tenha sido lido pelo sistema, esta coluna significa o valor corrente");
define("_MYLANGADMIN_NOTCREATED","Ainda não foi criado");
define("_MYLANGADMIN_NOTE_ADDEDBYMYLANG","(uma constante criada pelo utilizador)");
define("_MYLANGADMIN_TH_CONSTANTNAME","Nome da constante");
define("_MYLANGADMIN_TH_DEFAULTVALUE","Valor Padrão");
define("_MYLANGADMIN_TH_USERVALUE","Valor personalizado");
?>