<?php
// $Id: modinfo.php 1040 2011-11-06 05:24:00Z mikhail $
// License http://creativecommons.org/licenses/by/2.5/br/
define("_MI_ALTSYS_ADMIN_IN_THEME","Tema configurado para administrador");
define("_MI_ALTSYS_ADMIN_IN_THEMEDSC","Configure o nome do tema mostrado na área administrativa. Insira uma linha apenas depois da inclusão do common.php no mainfile.php<br />include XOOPS_TRUST_PATH.\"/libs/altsys/include/admin_in_theme.inc.php\";<br /> para habilitar isso. Esta característica trabalha somente com XOOPS 2.0.x");
define("_MI_ALTSYS_ADMINMENU_HFT","Reescrever o menu administrativo?");
define("_MI_ALTSYS_ADMINMENU_HFTDSC","Se seu menu administrativo estiver quebrado, remova o arquivo cache/adminmenu.php. Este macete só funciona com o XOOPS 2.0.x");
define("_MI_ALTSYS_ADMINMENU_IM","Importa os endereços do módulo <q>mymenu</q> para o <q>menu administrativo</q>");
define("_MI_ALTSYS_ADMINMENU_IMDSC","Se o seu menu administrativo estiver quebrado, remova o arquivo cache/adminmenu.php. Este macete só funciona com o XOOPS 2.0.x");
define("_MI_ALTSYS_AMHFT_OPT_2COL","Duas colunas para os ícones dos módulo");
define("_MI_ALTSYS_AMHFT_OPT_NOIMG","Não mostrar imagens , apenas os seus respectivos endereços em texto simples.");
define("_MI_ALTSYS_AMHFT_OPT_XCSTY","Como o XOOPS Cube");
define("_MI_ALTSYS_BNAME_ADMIN_MENU","Menu administrativo");
define("_MI_ALTSYS_ENABLEFORCECLONE","Tornar todos os blocos clonáveis");
define("_MI_ALTSYS_ENABLEFORCECLONEDSC","Esta opção permite que todos os blocos possam ser clonados. Antes de habilitar esta função, tenha em mente que alguns blocos causarão erros se forem mostrados mais de uma vez na mesma página.");
define("_MI_ALTSYS_IMAGES_DIR","Diretório para os arquivos de imagem");
define("_MI_ALTSYS_IMAGES_DIRDSC","O caminho relativo deve ser configurado no diretório do módulo. O padrão é <q>images</q>.");
define("_MI_ALTSYS_MENU_ADVANCEDLANGADMIN","Idiomas (avançado)");
define("_MI_ALTSYS_MENU_COMPILEHOOKADMIN","Modelos (avançado)");
define("_MI_ALTSYS_MENU_CUSTOMBLOCKS","Blocos personalizados");
define("_MI_ALTSYS_MENU_MYAVATAR","Avatares");
define("_MI_ALTSYS_MENU_MYBLOCKSADMIN","Blocos dos módulos");
define("_MI_ALTSYS_MENU_MYLANGADMIN","Idiomas");
define("_MI_ALTSYS_MENU_MYSMILEY","Ícones emotivos");
define("_MI_ALTSYS_MENU_MYTPLSADMIN","Modelos");
define("_MI_ALTSYS_MENU_NEWCUSTOMBLOCK","Criar um novo bloco");
define("_MI_ALTSYS_MODULEDESC","Módulo complementar para administração do sistema cuja instalação é necessária para o funcionamento de diversos módulos.");
define("_MI_ALTSYS_MODULENAME","Altsys legacy");
?>