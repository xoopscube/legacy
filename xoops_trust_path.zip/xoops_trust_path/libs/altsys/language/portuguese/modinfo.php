<?php
// $Id: modinfo.php 1040 2011-11-06 05:24:00Z mikhail $
// License http://creativecommons.org/licenses/by/2.5/br/
define("_MI_ALTSYS_ADMIN_IN_THEME","Tema configurado para administrador");
define("_MI_ALTSYS_ADMIN_IN_THEMEDSC","Configure o nome do tema mostrado na �rea administrativa. Insira uma linha apenas depois da inclus�o do common.php no mainfile.php<br />include XOOPS_TRUST_PATH.\"/libs/altsys/include/admin_in_theme.inc.php\";<br /> para habilitar isso. Esta caracter�stica trabalha somente com XOOPS 2.0.x");
define("_MI_ALTSYS_ADMINMENU_HFT","Reescrever o menu administrativo?");
define("_MI_ALTSYS_ADMINMENU_HFTDSC","Se seu menu administrativo estiver quebrado, remova o arquivo cache/adminmenu.php. Este macete s� funciona com o XOOPS 2.0.x");
define("_MI_ALTSYS_ADMINMENU_IM","Importa os endere�os do m�dulo <q>mymenu</q> para o <q>menu administrativo</q>");
define("_MI_ALTSYS_ADMINMENU_IMDSC","Se o seu menu administrativo estiver quebrado, remova o arquivo cache/adminmenu.php. Este macete s� funciona com o XOOPS 2.0.x");
define("_MI_ALTSYS_AMHFT_OPT_2COL","Duas colunas para os �cones dos m�dulo");
define("_MI_ALTSYS_AMHFT_OPT_NOIMG","N�o mostrar imagens , apenas os seus respectivos endere�os em texto simples.");
define("_MI_ALTSYS_AMHFT_OPT_XCSTY","Como o XOOPS Cube");
define("_MI_ALTSYS_BNAME_ADMIN_MENU","Menu administrativo");
define("_MI_ALTSYS_ENABLEFORCECLONE","Tornar todos os blocos clon�veis");
define("_MI_ALTSYS_ENABLEFORCECLONEDSC","Esta op��o permite que todos os blocos possam ser clonados. Antes de habilitar esta fun��o, tenha em mente que alguns blocos causar�o erros se forem mostrados mais de uma vez na mesma p�gina.");
define("_MI_ALTSYS_IMAGES_DIR","Diret�rio para os arquivos de imagem");
define("_MI_ALTSYS_IMAGES_DIRDSC","O caminho relativo deve ser configurado no diret�rio do m�dulo. O padr�o � <q>images</q>.");
define("_MI_ALTSYS_MENU_ADVANCEDLANGADMIN","Idiomas (avan�ado)");
define("_MI_ALTSYS_MENU_COMPILEHOOKADMIN","Modelos (avan�ado)");
define("_MI_ALTSYS_MENU_CUSTOMBLOCKS","Blocos personalizados");
define("_MI_ALTSYS_MENU_MYAVATAR","Avatares");
define("_MI_ALTSYS_MENU_MYBLOCKSADMIN","Blocos dos m�dulos");
define("_MI_ALTSYS_MENU_MYLANGADMIN","Idiomas");
define("_MI_ALTSYS_MENU_MYSMILEY","�cones emotivos");
define("_MI_ALTSYS_MENU_MYTPLSADMIN","Modelos");
define("_MI_ALTSYS_MENU_NEWCUSTOMBLOCK","Criar um novo bloco");
define("_MI_ALTSYS_MODULEDESC","M�dulo complementar para administra��o do sistema cuja instala��o � necess�ria para o funcionamento de diversos m�dulos.");
define("_MI_ALTSYS_MODULENAME","Altsys legacy");
?>