<?php
// $Id: mytplsadmin.php 1040 2011-11-06 05:24:00Z mikhail $
// License http://creativecommons.org/licenses/by/2.5/br/
define("_MYTPLSADMIN_BTN_COPY","Copiar");
define("_MYTPLSADMIN_BTN_NEWTPLSET","Criar");
define("_MYTPLSADMIN_CAPTION_BASE","Base");
define("_MYTPLSADMIN_CAPTION_COPYTO","para");
define("_MYTPLSADMIN_CAPTION_SETNAME","Nome");
define("_MYTPLSADMIN_CNF_COPY_SELECTED_TEMPLATES","Todos os modelos marcados nesta configura��o (coluna) ser�o copiados ou sobreescritos na configura��o selecionada. Voc� confirma?");
define("_MYTPLSADMIN_CNF_DELETE_SELECTED_TEMPLATES","Todos os modelos marcados nesta configura��o (coluna) ser�o removidos. Voc� confirma?");
define("_MYTPLSADMIN_CREATE_NEW_TPLSET","Criar um novo Conjunto de Modelos");
define("_MYTPLSADMIN_CREATENEWCUSTOMTEMPLATE","Criar um novo modelo padronizado");
define("_MYTPLSADMIN_CUSTOMTEMPLATE","Modelos personalizados");
define("_MYTPLSADMIN_DBUPDATED","Os modelos foram atualizados corretamente.");
define("_MYTPLSADMIN_ERR_CANTREMOVEDEFAULT","Voc� n�o pode remover o Conjunto de Modelos Padr�o.");
define("_MYTPLSADMIN_ERR_DUPLICATEDSETNAME","O nome configurado j� existe.");
define("_MYTPLSADMIN_ERR_INVALIDSETNAME","configurado errado o nome especificado.");
define("_MYTPLSADMIN_ERR_INVALIDTPLSET","O destino escolhido, ou o conjunto de modelos especificado, foi considerado inv�lido.");
define("_MYTPLSADMIN_ERR_NOTPLFILE","Nenhum modelo foi marcado.");
define("_MYTPLSADMIN_H3_MODULE","M�dulo");
define("_MYTPLSADMIN_OPT_BLANKSET","(vazio)");
define("_MYTPLSADMIN_TH_FILE","Arquivo base");
define("_MYTPLSADMIN_TH_NAME","Nome do modelo");
define("_MYTPLSADMIN_TH_TYPE","Tipo");
define("_MYTPLSADMIN_TITLE_CHECKALL","Marcar ou desmarcar todas as caixas de sele��o desta coluna");
?>