<?php
// $Id: blocks_each.php 1040 2011-11-06 05:24:00Z mikhail $
// License http://creativecommons.org/licenses/by/2.5/br/
if(defined('FOR_XOOPS_LANG_CHECKER')) $mydirname = 'd3forum';
$constpref = '_MB_' . strtoupper($mydirname);
if(defined('FOR_XOOPS_LANG_CHECKER') || ! defined($constpref.'_LOADED')) {
define($constpref.'_LOADED' , 1);
// DEFINITIONS FOR DISPLAYING BLOCKS
// SINCE ALTSYS IS A SINGLETON MODULE, THIS FILE HAS NON-SENSE.
}
?>