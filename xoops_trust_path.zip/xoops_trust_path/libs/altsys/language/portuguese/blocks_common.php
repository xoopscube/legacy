<?php
// $Id: blocks_common.php 1040 2011-11-06 05:24:00Z mikhail $
// License http://creativecommons.org/licenses/by/2.5/br/
define("_MB_ALTSYS_OPENCLOSE","Abrir/fechar");
define("_MB_ALTSYS_THISTEMPLATE","Modelo deste bloco");
?>