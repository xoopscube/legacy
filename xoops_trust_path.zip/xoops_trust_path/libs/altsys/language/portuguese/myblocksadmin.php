<?php
// $Id: myblocksadmin.php 1040 2011-11-06 05:24:00Z mikhail $
// License http://creativecommons.org/licenses/by/2.5/br/
define("_MD_A_MYBLOCKSADMIN_ACTION","A��o");
define("_MD_A_MYBLOCKSADMIN_ALLPAGES","Todas as p�ginas");
define("_MD_A_MYBLOCKSADMIN_BCACHETIME","Tempo do Cache");
define("_MD_A_MYBLOCKSADMIN_BLOCKADMIN","Gerir os blocos");
define("_MD_A_MYBLOCKSADMIN_BTN_CLONE","Clonar");
define("_MD_A_MYBLOCKSADMIN_BTN_EDIT","Atualizar");
define("_MD_A_MYBLOCKSADMIN_BTN_NEW","Criar");
define("_MD_A_MYBLOCKSADMIN_CAPT_USABLETAGS","Utilizar tags");
define("_MD_A_MYBLOCKSADMIN_CBCENTER","Centro");
define("_MD_A_MYBLOCKSADMIN_CBLEFT","Centro-esquero");
define("_MD_A_MYBLOCKSADMIN_CBRIGHT","Centro-direito");
define("_MD_A_MYBLOCKSADMIN_CLONEFORM","Clonar o bloco");
define("_MD_A_MYBLOCKSADMIN_CONTENT","Conte�do");
define("_MD_A_MYBLOCKSADMIN_CTYPE","Tipo personalizado");
define("_MD_A_MYBLOCKSADMIN_CTYPE_HTML","Personalizado (HTML simples)");
define("_MD_A_MYBLOCKSADMIN_CTYPE_NOSMILE","Personalizado (HTML+BBCODE+AutoLink)");
define("_MD_A_MYBLOCKSADMIN_CTYPE_PHP","Personalizado (PHP eval())");
define("_MD_A_MYBLOCKSADMIN_CTYPE_SMILE","Personalizado (HTML+BBCODE+AutoLink+Smiley)");
define("_MD_A_MYBLOCKSADMIN_DBUPDATED","Banco de dados atualizado corretamente");
define("_MD_A_MYBLOCKSADMIN_DESCRIPTION","Descri��o");
define("_MD_A_MYBLOCKSADMIN_EDITFORM","Editar o bloco");
define("_MD_A_MYBLOCKSADMIN_EDITTPL","Editar o modelo");
define("_MD_A_MYBLOCKSADMIN_FMT_REMOVEBLOCK","%s ser� removido. Voc� concorda?");
define("_MD_A_MYBLOCKSADMIN_FMT_TAGRULE","%s ser� substitu�do por %s.");
define("_MD_A_MYBLOCKSADMIN_LINK_FORCECLONE","For�ar clonagem");
define("_MD_A_MYBLOCKSADMIN_NAME","Nome");
define("_MD_A_MYBLOCKSADMIN_NEWFORM","Criar um novo bloco");
define("_MD_A_MYBLOCKSADMIN_NOTICE4COMMONFCK","Se voc� deseja utilizar um editor visual (WYSIWYG), instale-o em /common/fckeditor");
define("_MD_A_MYBLOCKSADMIN_OPTIONS","Blocos");
define("_MD_A_MYBLOCKSADMIN_PERM_MADMIN","Administrar");
define("_MD_A_MYBLOCKSADMIN_PERM_MREAD","Acessar");
define("_MD_A_MYBLOCKSADMIN_PERMADDNG","N�o foi poss�vel aplicar as permiss�es de %s ao m�dulo %s para o grupo %s");
define("_MD_A_MYBLOCKSADMIN_PERMADDNGP","Todos os itens relacionados tamb�m devem ser selecionados.");
define("_MD_A_MYBLOCKSADMIN_PERMADDOK","Foram aplicadas as permiss�es de %s ao m�dulo %s para o grupo %s.");
define("_MD_A_MYBLOCKSADMIN_PERMFORM","Permiss�es");
define("_MD_A_MYBLOCKSADMIN_PERMRESETNG","N�o foi poss�vel anular as permiss�es do grupo no m�dulo %s");
define("_MD_A_MYBLOCKSADMIN_PERMUPDATED","Permiss�es atualizadas corretamente");
define("_MD_A_MYBLOCKSADMIN_SBLEFT","Esquerdo");
define("_MD_A_MYBLOCKSADMIN_SBRIGHT","Direito");
define("_MD_A_MYBLOCKSADMIN_SIDE","Lado");
define("_MD_A_MYBLOCKSADMIN_TITLE","T�tulo");
define("_MD_A_MYBLOCKSADMIN_TOPPAGE","P�gina inicial");
define("_MD_A_MYBLOCKSADMIN_VISIBLE","Vis�vel");
define("_MD_A_MYBLOCKSADMIN_VISIBLEIN","Vis�vel em");
define("_MD_A_MYBLOCKSADMIN_WEIGHT","Peso");
?>