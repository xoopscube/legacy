<?php

// definitions for editing blocks
define("_MB_ALTSYS_OPENCLOSE","Ouvrir/Fermer");
define("_MB_ALTSYS_THISTEMPLATE","Template du bloc");

?>