<?php

define( '_MD_A_MYPREFERENCES_FORMTITLE' , 'Pr�f�rences Modules' ) ;
define( '_MD_A_MYPREFERENCES_UPDATED' , 'Mise � jour avec succ�s des pr�f�rences' ) ;

?>