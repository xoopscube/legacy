<?php

define( '_MD_A_AINTHEME_FMT_PUBLICTOP' , 'Public Top de %s' ) ;
define( '_MD_A_AINTHEME_FMT_ADMINTOP' , 'Admin Top de %s' ) ;


?>