<?php

define( '_MD_A_DBUPDATED' , 'Mise � jour avec succ�s de la Base De Donn�es' ) ;


?>