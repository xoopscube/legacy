<?php

define( '_MD_A_MYTPLSFORM_TPLSADMIN' , 'Templates' ) ;
define( '_MD_A_MYTPLSFORM_EDIT' , 'Edition du template' ) ;
define( '_MD_A_MYTPLSFORM_UPDATED' , 'Mise � jour avec succ�s du template' ) ;
define( '_MD_A_MYTPLSFORM_CREATED' , 'Template cr�� avec succ�s' ) ;
define( '_MD_A_MYTPLSFORM_LABEL_TPLFILE' , 'Nom du Template' ) ;
define( '_MD_A_MYTPLSFORM_BTN_MODIFYCONT' , 'Renvoyer' ) ;
define( '_MD_A_MYTPLSFORM_BTN_MODIFYEND' , 'Sauvegarder et Terminer' ) ;
define( '_MD_A_MYTPLSFORM_BTN_CREATE' , 'Cr�er' ) ;
define( '_MD_A_MYTPLSFORM_BTN_RESET' , 'Annuler' ) ;

?>