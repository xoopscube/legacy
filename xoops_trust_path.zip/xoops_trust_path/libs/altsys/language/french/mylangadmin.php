<?php

define( '_MYLANGADMIN_H3_MODULE' , 'Module cible' ) ;
define( '_MYLANGADMIN_CACHEUPDATED' , 'Le fichier de cache a �t� mis � jour' ) ;
define( '_MYLANGADMIN_BTN_UPDATE' , 'Mise � jour' ) ;
define( '_MYLANGADMIN_BTN_RESET' , 'r�initialiser' ) ;

define( '_MYLANGADMIN_TH_CONSTANTNAME' , 'Nom de la Constante' ) ;
define( '_MYLANGADMIN_TH_DEFAULTVALUE' , 'Valeur par d�faut' ) ;
define( '_MYLANGADMIN_TH_USERVALUE' , 'Valeur de Utilisateur' ) ;

define( '_MYLANGADMIN_NOTE_ADDEDBYMYLANG' , '(constante ajout�e par utilisateur)' ) ;
define( '_MYLANGADMIN_DT_MYLANGFILENAME' , 'Re�criture partielle du nom de fichier' ) ;

define( '_MYLANGADMIN_DT_CACHEFILENAME' , 'Nom du fichier en Cache' ) ;
define( '_MYLANGADMIN_DT_CACHESTATUS' , 'Mise en Cache du statut' ) ;
define( '_MYLANGADMIN_CREATED' , 'Cr��' ) ;
define( '_MYLANGADMIN_NOTCREATED' , 'N\'a pas �t� cr�� pour l\'instant' ) ;

define( '_MYLANGADMIN_ERR_MODNOLANGUAGE' , 'Le module s�lectionn� n\'a pas de dossier de la langue' ) ;
define( '_MYLANGADMIN_ERR_MODLANGINCOMPATIBLE' , 'Le module s�lectionn� a une structure incompatible' ) ;
define( '_MYLANGADMIN_ERR_MODEMPTYLANGDIR' , 'Le module s�lectionn� n\'a pas de fichier langue de re�criture' ) ;

define( '_MYLANGADMIN_MSG_D3LANGMANENABLED' , 'Le syst�me de re�criture est activ� d�s maintenant.' ) ;
define( '_MYLANGADMIN_FMT_HOWTOENABLED3LANGMAN4XCL' , 'Le syst�me de re�criture est d�sormais d�sactiv�. Pour l\'activer, copiez "%s" dans "%s"' ) ;
define( '_MYLANGADMIN_MSG_HOWTOENABLED3LANGMAN4X2' , 'Le syst�me de re�criture ne peut pas fonctionner avec ce noyau de XOOPS, sauf quelques modules D3. Si vous souhaitez l\'activer avec ce noyau, essayez de modifier comme ceci:' ) ;
define( '_MYLANGADMIN_MSG_NOTICE4ALREADYREAD' , 'Puisque ce fichier a d�j� �t� lu par le syst�me, cette colonne repr�sente la valeur actuelle' ) ;

?>