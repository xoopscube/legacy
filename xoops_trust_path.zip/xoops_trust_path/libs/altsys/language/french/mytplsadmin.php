<?php

define( '_MYTPLSADMIN_CREATE_NEW_TPLSET' , 'Cr�er une nouvelle s�rie' ) ;
define( '_MYTPLSADMIN_CAPTION_BASE' , 'Base' ) ;
define( '_MYTPLSADMIN_CAPTION_SETNAME' , 'nom' ) ;
define( '_MYTPLSADMIN_OPT_BLANKSET' , '(vide)' ) ;
define( '_MYTPLSADMIN_CAPTION_COPYTO' , '�' ) ;
define( '_MYTPLSADMIN_BTN_COPY' , 'COPIER' ) ;
define( '_MYTPLSADMIN_TITLE_CHECKALL' , 'Activer / d�sactiver toutes les cases de cette ligne' ) ;
define( '_MYTPLSADMIN_CNF_DELETE_SELECTED_TEMPLATES' , 'Tous les templates s�lectionn�s dans l\'ensemble (ligne) seront supprim�s. Voulez-vous confirmer?' ) ;
define( '_MYTPLSADMIN_CNF_COPY_SELECTED_TEMPLATES' , 'Tous les templates s�lectionn�s dans l\'ensemble (ligne) seront copi�s/�cras� dans l\'ensemble s�lectionn�. Voulez-vous confirmer?' ) ;
define( '_MYTPLSADMIN_TH_NAME' , 'Nom template name' ) ;
define( '_MYTPLSADMIN_TH_TYPE' , 'type' ) ;
define( '_MYTPLSADMIN_TH_FILE' , 'fichier source' ) ;
define( '_MYTPLSADMIN_ERR_NOTPLFILE' , "Aucun template s�lectionn�." ) ;
define( '_MYTPLSADMIN_ERR_INVALIDTPLSET' , "L\'ensemble de destination est le m�me que la source, ou aucun ensemble de templates n\'a �t� sp�cifi�." ) ;
define( '_MYTPLSADMIN_ERR_CANTREMOVEDEFAULT' , "Vous ne pouvez pas supprimer l'ensemble 'default'." ) ;
define( '_MYTPLSADMIN_ERR_DUPLICATEDSETNAME' , "Ce nom d'ensemble de templates existe d�j�." ) ;
define( '_MYTPLSADMIN_ERR_INVALIDSETNAME' , "un mauvais nom d'ensemble de templates a �t� sp�cifi�." ) ;

define( '_MYTPLSADMIN_H3_MODULE' , 'Module' ) ;
define( '_MYTPLSADMIN_BTN_NEWTPLSET' , 'cr�er' ) ;

define( '_MYTPLSADMIN_DBUPDATED' , 'Mise � jour avec succ�s des Templates' ) ;

define( '_MYTPLSADMIN_CUSTOMTEMPLATE' , 'Template personnalis�' ) ;
define( '_MYTPLSADMIN_CREATENEWCUSTOMTEMPLATE' , 'Cr�er un nouveau template personnalis�' ) ;

?>