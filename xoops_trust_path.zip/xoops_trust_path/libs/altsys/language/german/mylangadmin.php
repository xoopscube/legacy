<?php


// Appended by Xoops Language Checker -GIJOE- in 2007-12-29 06:46:09
define('_MYLANGADMIN_NOTE_ADDEDBYMYLANG','(a constant added by user)');
define('_MYLANGADMIN_DT_MYLANGFILENAME','Partially overriding file name');

define( '_MYLANGADMIN_H3_MODULE' , 'Ziel-Modul' ) ;
define( '_MYLANGADMIN_CACHEUPDATED' , 'Die Cache-Datei wurde erneuert' ) ;
define( '_MYLANGADMIN_BTN_UPDATE' , 'Update' ) ;
define( '_MYLANGADMIN_BTN_RESET' , 'Reset' ) ;

define( '_MYLANGADMIN_TH_CONSTANTNAME' , 'Sprachkennzeichnung' ) ;
define( '_MYLANGADMIN_TH_DEFAULTVALUE' , 'Default-Wert' ) ;
define( '_MYLANGADMIN_TH_USERVALUE' , 'User-Wert' ) ;

define( '_MYLANGADMIN_DT_CACHEFILENAME' , 'Cache Dateiname' ) ;
define( '_MYLANGADMIN_DT_CACHESTATUS' , 'Cache Status' ) ;
define( '_MYLANGADMIN_CREATED' , 'Created' ) ;
define( '_MYLANGADMIN_NOTCREATED' , 'Has not created yet' ) ;

define( '_MYLANGADMIN_ERR_MODNOLANGUAGE' , 'Das gew�hlte Modul hat keinen Sprachordner' ) ;
define( '_MYLANGADMIN_ERR_MODLANGINCOMPATIBLE' , 'Das gew�hlte Modul ist inkompatibel mit der XOOPS Sprachstruktur' ) ;
define( '_MYLANGADMIN_ERR_MODEMPTYLANGDIR' , 'Selected module does not have overridable language file' ) ;

define( '_MYLANGADMIN_MSG_D3LANGMANENABLED' , 'The overriding system is enabled now.' ) ;
define( '_MYLANGADMIN_FMT_HOWTOENABLED3LANGMAN4XCL' , 'The overriding system is disabled now. To enable it, copy "%s" into "%s"' ) ;
define( '_MYLANGADMIN_MSG_HOWTOENABLED3LANGMAN4X2' , 'The overriding system cannot work with this XOOPS core except some D3 modules. If you want to enable it with this core, try to hack like this:' ) ;
define( '_MYLANGADMIN_MSG_NOTICE4ALREADYREAD' , 'Since this file has been already read by system, this column means current value' ) ;

?>