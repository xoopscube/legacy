<?php



// Appended by Xoops Language Checker -GIJOE- in 2008-07-09 13:28:57
define('_MD_A_MYTPLSFORM_TPLSADMIN','Templates');

// Appended by Xoops Language Checker -GIJOE- in 2007-12-28 04:46:28
define('_MD_A_MYTPLSFORM_CREATED','A template is created successfully');
define('_MD_A_MYTPLSFORM_LABEL_TPLFILE','Template name');
define('_MD_A_MYTPLSFORM_BTN_CREATE','Create');

define( '_MD_A_MYTPLSFORM_EDIT' , 'Template bearbeiten' ) ;
define( '_MD_A_MYTPLSFORM_UPDATED' , 'Template erfolgreich aktualisiert' ) ;
define( '_MD_A_MYTPLSFORM_BTN_MODIFYCONT' , 'Reflect' ) ;
define( '_MD_A_MYTPLSFORM_BTN_MODIFYEND' , 'Speichern und Ende' ) ;
define( '_MD_A_MYTPLSFORM_BTN_RESET' , 'Reset' ) ;

?>