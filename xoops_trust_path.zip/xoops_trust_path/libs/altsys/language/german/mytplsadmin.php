<?php


// Appended by Xoops Language Checker -GIJOE- in 2007-12-28 04:46:28
define('_MYTPLSADMIN_CUSTOMTEMPLATE','Custom template');
define('_MYTPLSADMIN_CREATENEWCUSTOMTEMPLATE','Create a new custom template');

define( '_MYTPLSADMIN_CREATE_NEW_TPLSET' , 'Erstelle ein neues Template-Set' ) ;
define( '_MYTPLSADMIN_CAPTION_BASE' , 'auf Basis von' ) ;
define( '_MYTPLSADMIN_CAPTION_SETNAME' , 'Name' ) ;
define( '_MYTPLSADMIN_OPT_BLANKSET' , '(blank)' ) ;
define( '_MYTPLSADMIN_CAPTION_COPYTO' , 'nach' ) ;
define( '_MYTPLSADMIN_BTN_COPY' , 'KOPIEREN' ) ;
define( '_MYTPLSADMIN_TITLE_CHECKALL' , 'Turn on/off all of checkboxes in this row' ) ;
define( '_MYTPLSADMIN_CNF_DELETE_SELECTED_TEMPLATES' , 'All of checked templates in the set(row) will be removed. Are you OK?' ) ;
define( '_MYTPLSADMIN_CNF_COPY_SELECTED_TEMPLATES' , 'All of checked templates in the set(row) will be copied/overwritten into the selected set. Are you OK?' ) ;
define( '_MYTPLSADMIN_TH_NAME' , 'Template Name' ) ;
define( '_MYTPLSADMIN_TH_TYPE' , 'Typ' ) ;
define( '_MYTPLSADMIN_TH_FILE' , 'Basis Datei' ) ;
define( '_MYTPLSADMIN_ERR_NOTPLFILE' , "No template is checked." ) ;
define( '_MYTPLSADMIN_ERR_INVALIDTPLSET' , "Destination set is same as source set, or no valid tplset is specified." ) ;
define( '_MYTPLSADMIN_ERR_CANTREMOVEDEFAULT' , "You can't remove 'default' template." ) ;
define( '_MYTPLSADMIN_ERR_DUPLICATEDSETNAME' , "The set name already exists." ) ;
define( '_MYTPLSADMIN_ERR_INVALIDSETNAME' , "a wrong set name is specified." ) ;

define( '_MYTPLSADMIN_H3_MODULE' , 'Module' ) ;
define( '_MYTPLSADMIN_BTN_NEWTPLSET' , 'jetzt erstellen' ) ;

define( '_MYTPLSADMIN_DBUPDATED' , 'Templates updated successfully' ) ;

?>