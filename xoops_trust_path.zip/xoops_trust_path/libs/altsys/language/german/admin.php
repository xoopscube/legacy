<?php

define( '_MD_A_DBUPDATED' , 'Datenbank erfolgreich aktualisiert' ) ;


?>