<?php


// Appended by Xoops Language Checker -GIJOE- in 2008-12-13 18:32:09
define('_MD_A_MYBLOCKSADMIN_NOTICE4COMMONFCK','If you want to use WYSIWYG editor, install common/fckeditor');

define( '_MD_A_MYBLOCKSADMIN_PERMUPDATED' , 'Berechtigungen erfolgreich �bernommen' ) ;
define( '_MD_A_MYBLOCKSADMIN_BLOCKADMIN' , 'Administration der Bl�cke' ) ;
define( '_MD_A_MYBLOCKSADMIN_NAME' , 'Name' ) ;
define( '_MD_A_MYBLOCKSADMIN_TITLE' , 'Titel' ) ;
define( '_MD_A_MYBLOCKSADMIN_SIDE' , 'Ausrichtung' ) ;
define( '_MD_A_MYBLOCKSADMIN_SBLEFT' , 'o --- - LINKS' ) ;
define( '_MD_A_MYBLOCKSADMIN_SBRIGHT' , '- --- o RECHTS' ) ;
define( '_MD_A_MYBLOCKSADMIN_CBLEFT' , '- o-- - MITTELINKS' ) ;
define( '_MD_A_MYBLOCKSADMIN_CBRIGHT' , '- --o - MITTERECHTS' ) ;
define( '_MD_A_MYBLOCKSADMIN_CBCENTER' , '- -o- - MITTE' ) ;
define( '_MD_A_MYBLOCKSADMIN_VISIBLE' , 'Sichtbar' ) ;
define( '_MD_A_MYBLOCKSADMIN_WEIGHT' , 'Gewichtung' ) ;
define( '_MD_A_MYBLOCKSADMIN_VISIBLEIN' , 'Sichtbar in' ) ;
define( '_MD_A_MYBLOCKSADMIN_CONTENT' , 'Content' ) ;
define( '_MD_A_MYBLOCKSADMIN_CAPT_USABLETAGS' , 'N�tzliche Tags' ) ;
define( '_MD_A_MYBLOCKSADMIN_FMT_TAGRULE' , '%s will be replaced into %s in the view' ) ;
define( '_MD_A_MYBLOCKSADMIN_CTYPE' , 'Blocktyp' ) ;
define( '_MD_A_MYBLOCKSADMIN_EDITTPL' , 'Template bearbeiten' ) ;
define( '_MD_A_MYBLOCKSADMIN_OPTIONS' , 'Block\'s option' ) ;
define( '_MD_A_MYBLOCKSADMIN_BCACHETIME' , 'Cache Zeit' ) ;
define( '_MD_A_MYBLOCKSADMIN_ACTION' , 'Action' ) ;
define( '_MD_A_MYBLOCKSADMIN_DESCRIPTION' , 'Bechreibung' ) ;
define( '_MD_A_MYBLOCKSADMIN_TOPPAGE' , 'Startseite' ) ;
define( '_MD_A_MYBLOCKSADMIN_ALLPAGES' , 'auf allen Seiten' ) ;
define( '_MD_A_MYBLOCKSADMIN_PERMFORM' , 'Berechtigungen' ) ;
define( '_MD_A_MYBLOCKSADMIN_PERM_MADMIN' , 'module admin' ) ;
define( '_MD_A_MYBLOCKSADMIN_PERM_MREAD' , 'module read' ) ;
define( '_MD_A_MYBLOCKSADMIN_DBUPDATED' , 'Datenbank wurde erfolgreich aktualisiert' ) ;
define( '_MD_A_MYBLOCKSADMIN_FMT_REMOVEBLOCK' , '%s soll gel�scht werden. Ist das wiklich OK?' ) ;


define( '_MD_A_MYBLOCKSADMIN_CLONEFORM' , 'Clone the block' ) ;
define( '_MD_A_MYBLOCKSADMIN_NEWFORM' , 'Erstelle einen Block' ) ;
define( '_MD_A_MYBLOCKSADMIN_EDITFORM' , 'Block bearbeiten' ) ;

define( '_MD_A_MYBLOCKSADMIN_LINK_FORCECLONE' , 'Force clone' ) ;

define( '_MD_A_MYBLOCKSADMIN_BTN_CLONE' , 'Clone' ) ;
define( '_MD_A_MYBLOCKSADMIN_BTN_NEW' , 'Create' ) ;
define( '_MD_A_MYBLOCKSADMIN_BTN_EDIT' , 'Update' ) ;

define( '_MD_A_MYBLOCKSADMIN_CTYPE_HTML' , '(normales HTML)' ) ;
define( '_MD_A_MYBLOCKSADMIN_CTYPE_NOSMILE' , 'HTML+BBCODE+AutoLink+Smiley aus' ) ;
define( '_MD_A_MYBLOCKSADMIN_CTYPE_SMILE' , 'HTML+BBCODE+AutoLink+Smiley an' ) ;
define( '_MD_A_MYBLOCKSADMIN_CTYPE_PHP' , 'PHP-Skript' ) ;


// Group permission phrases
define('_MD_A_MYBLOCKSADMIN_PERMADDNG', 'Could not add %s permission to %s for group %s');
define('_MD_A_MYBLOCKSADMIN_PERMADDOK','Added %s permission to %s for group %s');
define('_MD_A_MYBLOCKSADMIN_PERMRESETNG','Could not reset group permission for module %s');
define('_MD_A_MYBLOCKSADMIN_PERMADDNGP', 'All parent items must be selected.');


?>
