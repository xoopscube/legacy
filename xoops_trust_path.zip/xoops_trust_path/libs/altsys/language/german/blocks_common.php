<?php

// definitions for editing blocks
define("_MB_ALTSYS_OPENCLOSE","Open/Close");
define("_MB_ALTSYS_THISTEMPLATE","Template von diesem Block");

?>