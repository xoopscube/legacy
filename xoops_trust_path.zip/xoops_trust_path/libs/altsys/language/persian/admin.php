<?php
/**
* Translation of altsys for Persian users
*
* @copyright	      http://www.impresscms.ir/ The Persian ImpressCMS Project 
* @copyright	http://www.irxoops.org/ The Persian XOOPS support site
* @license		http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU General Public License (GPL)
* @package	      Translations
* @since		 0.70
* @author		stranger <pesian_stranger@users.sourceforge.net>
* @author		voltan   <djvoltan@gmail.com>
* @version		$Id$
*/

define( '_MD_A_DBUPDATED' , 'پایگاه داده‌ها با موفقیت به روز شد' ) ;


?>