<?php
include 'mytplsadmin.php';
?>