<?php
/**
 * @file
 * @package mydhtml
 * @version $Id$
 */

if (!defined('XOOPS_ROOT_PATH')) exit();

class Mydhtml_AssetPreload extends XCube_ActionFilter
{
	/**
	 * @public
	 */
	function preBlockFilter()
	{
		if (!$this->mRoot->mContext->hasAttribute('module.mydhtml.HasSetAssetManager')) {
			$delegate =& new XCube_Delegate();
			$delegate->register('Module.mydhtml.Event.GetAssetManager');
			$delegate->add(array(&$this, 'getManager'));
			$this->mRoot->mContext->setAttribute('module.mydhtml.HasSetAssetManager', true);
		}
	}

	/**
	 * @private
	 */
	function getManager(&$obj)
	{
		require_once XOOPS_MODULE_PATH . "/mydhtml/class/AssetManager.class.php";
		$obj = Mydhtml_AssetManager::getSingleton();
	}
}

?>
