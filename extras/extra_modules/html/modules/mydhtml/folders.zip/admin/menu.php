<?php
/**
 * @file
 * @package mydhtml
 * @version $Id$
 */

if (!defined('XOOPS_ROOT_PATH')) exit();

//
// The menu in control panel. You must never change [cubson] chunk to get the help of cubson.
//
// $adminmenu[]['title'] = CONSTRACT;
// $adminmenu[]['link'] = URL;
// $adminmenu[]['keywords'] = CONSTRACT;
// $adminmenu[]['show'] = bool;
//
##[cubson:adminmenu]
##[/cubson:adminmenu]

?>
