<?php
/**
 * @file
 * @package mydhtml
 * @version $Id$
 */

if (!defined('XOOPS_ROOT_PATH')) exit();

require_once dirname(__FILE__) . "/AbstractEditAction.class.php";

class Mydhtml_AbstractDeleteAction extends Mydhtml_AbstractEditAction
{
	/**
	 * @protected
	 */
	function _isEnableCreate()
	{
		return false;
	}

	/**
	 * @public
	 */
	function prepare()
	{
		parent::prepare();
		return is_object($this->mObject);
	}

	/**
	 * @protected
	 */
	function _doExecute()
	{
		if ($this->mObjectHandler->delete($this->mObject)) {
			return MYDHTML_FRAME_VIEW_SUCCESS;
		}
	
		return MYDHTML_FRAME_VIEW_ERROR;
	}
}

?>
